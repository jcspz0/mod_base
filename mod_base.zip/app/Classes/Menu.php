<?php

namespace base\Classes;

//use \base\Model\Parametro;

class Menu {
    public $menu;
    public $items;
}
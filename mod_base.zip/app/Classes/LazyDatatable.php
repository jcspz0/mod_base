<?php

namespace base\Classes;

class LazyDatatable {

    public $draw;
    public $recordsFiltered;
    public $recordsTotal;
    public $data;
    /*public $data = array("fechaHora" => "", 
    					 "accion" => "",
    					 "formulario" => "",
    					 "usuario" => "",
    					 "descripcion" => "",
    					 "direccionIp" => "");*/

}
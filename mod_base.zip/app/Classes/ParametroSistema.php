<?php

namespace base\Classes;

use \base\Model\Parametro;

class ParametroSistema {

	/*public $parametros = "";

    public static function cargar(){
    	if (isset($this->parametros)){
    		echo "tiene elemento: ".count($this->parametros);
    	}
    	else{
    		echo "es vacio: ";
    		$parametros = Parametro::all();
    		echo "AHORA NO ES VACIO: ".count($parametros);
            dd($parametros);
    	}
    }

    public static function getParametro($id){
        echo "ID: ".$id;
        dd($this->parametros);
    }*/
}
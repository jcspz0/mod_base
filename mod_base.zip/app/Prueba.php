<?php

namespace base;

use Illuminate\Database\Eloquent\Model;

class Prueba extends Model
{
    //
}

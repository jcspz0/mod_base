<?php

namespace base\Events;

abstract class Event
{
    //
}

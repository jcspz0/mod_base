function holaFranz(){
	alert("HOLA FRANZ...");
}
INGRESANDO A IMAGEN1: aaa
<div>
	{!! Html::image('img/calendar.png', "Imagen no encontrada", ['id' => 'imgCalender', 'title' => 'imagen1']) !!}
</div>
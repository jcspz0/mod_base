<div>
	{!! Html::image('img/calendar.png', "Imagen no encontrada", ['id' => 'imgCalender', 'title' => 'imagen2']) !!}
</div>